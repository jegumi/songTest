package com.jegumi.songkick.model;

import java.io.Serializable;

public class Identifier implements Serializable {

    public String setlistsHref;
    public String href;
    public String mbid;
    public String eventsHref;
}
