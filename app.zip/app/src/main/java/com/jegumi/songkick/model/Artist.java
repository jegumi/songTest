package com.jegumi.songkick.model;

import java.io.Serializable;

public class Artist implements Serializable {

    public String onTourUntil;
    public Identifier[] identifier;
    public String displayName;
    public String uri;
    public String id;


}
