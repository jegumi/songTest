package com.jegumi.songkick.model;

import java.io.Serializable;

public class Result implements Serializable {

    public Artist[] artist;
}
