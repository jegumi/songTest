package com.jegumi.songkick.model;

import java.io.Serializable;

public class Root implements Serializable {

    public ResultsPage resultsPage;
}
